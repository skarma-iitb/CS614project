rm *.class
rm syntaxtree/*.class
rm visitor/*.class

rm *.DOT