rm input-grammar/*.class
rm input-grammar/visitor/*.class
rm input-grammar/syntaxtree/*.class

rm output-grammar/*.class
rm output-grammar/visitor/*.class
rm output-grammar/syntaxtree/*.class

rm public-testcase/*.class
rm public-testcase/a3/*.class

rm testcase-output/*.class
rm testcase-output/a3/*.class