package visitor;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import syntaxtree.*;

public class a4help extends GJNoArguDepthFirst<String> {
    public Map<String, Map<String, String>> methodthis;
    private String currentClass;
    public Map<String, Boolean> callmethod;
    private String key;

    public a4help() {
        methodthis = new HashMap<>();
        callmethod = new HashMap<>();
    }

    public Map<String, Map<String, String>> getMethodthis() {
        return methodthis;
    }

    public Map<String, Boolean> getMethodcall() {
        return callmethod;
    }

    @Override
    public String visit(Goal n) {
        String _ret = null;
        // n.f0.accept(this);
        n.f1.accept(this);
        n.f2.accept(this);
        return _ret;
    }

    @Override
    public String visit(NodeList n) {
        // String _ret = null;
        int _count = 0;
        for (Enumeration<Node> e = n.elements(); e.hasMoreElements();) {
            e.nextElement().accept(this);
            _count++;
        }
        return "";
    }

    @Override
    public String visit(NodeListOptional n) {
        if (n.present()) {
            // R _ret = null;
            int _count = 0;
            for (Enumeration<Node> e = n.elements(); e.hasMoreElements();) {
                e.nextElement().accept(this);
                _count++;
            }
            return "";
        } else
            return "";
    }

    @Override
    public String visit(NodeOptional n) {
        if (n.present())
            return n.node.accept(this);
        else
            return "";
    }

    @Override
    public String visit(NodeSequence n) {
        // String _ret = null;
        int _count = 0;
        for (Enumeration<Node> e = n.elements(); e.hasMoreElements();) {
            e.nextElement().accept(this);
            _count++;
        }
        return "";
    }

    @Override
    public String visit(NodeToken n) {
        return "";
    }

    @Override
    public String visit(ClassDeclaration n) {
        currentClass = n.f1.f0.tokenImage;
        super.visit(n);
        // currentClass = null;
        return null;
    }

    @Override
    public String visit(ClassExtendsDeclaration n) {
        currentClass = n.f1.f0.tokenImage;
        super.visit(n);
        // currentClass = null;
        return null;
    }

    @Override
    public String visit(MethodDeclaration n) {
        String methodName = n.f2.f0.toString();
        String className = currentClass;
        key = className + "_" + methodName;
        super.visit(n);
        return "";
    }

    @Override
    public String visit(ThisStoreStatement n) {
        String _ret = null;
        n.f0.accept(this);
        n.f1.accept(this);
        n.f2.accept(this);
        n.f3.accept(this);
        n.f4.accept(this);
        n.f5.accept(this);
        methodthis.computeIfAbsent(key, k -> new HashMap<>())
                .put(currentClass, "th");
        // System.out.println(key + " -> " + "Var: " + currentClass + " Type: th");
        // methodBody.append("this").append(n.f1.tokenImage).append(n.f2.f0.toString()).append(n.f3.tokenImage)
        // .append(n.f4.accept(this)).append(n.f5.tokenImage + "\n");
        return _ret;
    }

    @Override
    public String visit(VarDeclaration n) {
        String varName = n.f1.f0.toString();
        String varType = extractFieldType(n.f0);
        if (!(varType.equals("int") || varType.equals("boolean") || varType.equals("int[]"))) {
            methodthis.computeIfAbsent(key, k -> new HashMap<>())
                    .put(varType, varName);
            // System.out.println(key + " -> " + "Var: " + varName + " Type: " + varType);
        }
        // String ret = " " + varType + " " + varName + ";\n";
        // if (inmethod) {
        // methodBody.append(ret);
        // }
        return "";
    }

    @Override
    public String visit(MessageSend n) {
        String _ret = null;
        String methodName = n.f2.f0.toString();
        n.f0.accept(this);
        n.f1.accept(this);
        n.f2.accept(this);
        n.f3.accept(this);
        n.f4.accept(this);
        n.f5.accept(this);
        callmethod.put(methodName, true);
        // System.out.println("Method called: " + methodName);
        return _ret;
    }

    private String extractFieldType(Type typeNode) {
        if (typeNode.f0.choice instanceof Identifier) {
            // methodthis.putIfAbsent(typeNode.f0.toString(), null);
            return ((Identifier) typeNode.f0.choice).f0.toString();
        } else if (typeNode.f0.choice instanceof ArrayType) {
            return "int[]";
        } else if (typeNode.f0.choice instanceof BooleanType) {
            return "boolean";
        } else if (typeNode.f0.choice instanceof IntegerType) {
            return "int";
        }
        return "";
    }

    public void printThisVar() {
        for (Map.Entry<String, Map<String, String>> outerEntry : methodthis.entrySet()) {
            String outerKey = outerEntry.getKey();
            Map<String, String> innerMap = outerEntry.getValue();

            // If you want to handle the case where the inner map is null, add a check:
            if (innerMap != null) {
                for (Map.Entry<String, String> innerEntry : innerMap.entrySet()) {
                    String innerKey = innerEntry.getKey();
                    String value = innerEntry.getValue();

                    System.out.println("Outer key: " + outerKey +
                            ", Inner key: " + innerKey +
                            ", Value: " + value);
                }
            } else {
                System.out.println("Outer key: " + outerKey + " has a null inner map.");
            }
        }
    }
}
