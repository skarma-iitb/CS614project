import syntaxtree.*;
import visitor.*;
import java.util.Map;
import java.util.HashMap;

public class Main {
   public static void main(String[] args) {
      try {
         Node root = new a4javaout(System.in).Goal();
         // Object o = root.accept(new GJNoArguDepthFirst());
         // System.out.println("Program Parsed Sucessfully.");
         a4help vst = new a4help();
         root.accept(vst);
         Map<String, Map<String, String>> thisvar = new HashMap<>();
         thisvar = vst.getMethodthis();
         // vst.printThisVar();
         Map<String, Boolean> callmethod = new HashMap<>();
         callmethod = vst.getMethodcall();
         a4 visitor = new a4(thisvar, callmethod);
         root.accept(visitor);
         // visitor.printClassMethodMap();
         Map<String, String> staticinfo = visitor.getClassMethod();
         idfa vis = new idfa(staticinfo);
         root.accept(vis);
         String out = vis.getOutput1();
         System.out.println(out);
         // vis.printdetails();
         // visitor.printClassMethodMap();
         // visitor.printObjectType();
         // visitor.printParentClassMap();
         // Call your visitor here
      } catch (

      ParseException e) {
         System.out.println(e.toString());
      }
   }
}
